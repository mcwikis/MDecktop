#include<windows.h>
#include<map>
#include<vector>
#include<sstream>
using namespace std;
HHOOK hook;
int desktops=1;
map<int,char> name;
vector<HWND> all_windows[100];
HWND hwndMain;
HFONT hFont;
void updateOverlayText(){InvalidateRect(hwndMain,NULL,TRUE);}
void turn_desktop(int now_desktop,int next_desktop)
{
	HWND hwnd=GetTopWindow(NULL);
	while(hwnd)
	{
		char className[256];
		GetClassName(hwnd,className,sizeof(className));
		if(IsWindowVisible(hwnd) && strcmp(className,"Progman")!=0 && strcmp(className,"Shell_TrayWnd")!=0 && strcmp(className,"MDesktop_Class")!=0)
		{
			all_windows[now_desktop].push_back(hwnd);
			ShowWindow(hwnd,SW_HIDE);
		}
		hwnd=GetNextWindow(hwnd,GW_HWNDNEXT);
	}
	for(HWND hwnd:all_windows[next_desktop])ShowWindow(hwnd,SW_SHOW);
	all_windows[next_desktop].clear();
	desktops=next_desktop;
	updateOverlayText();
}
LRESULT CALLBACK LowLevelKeyboardProc(int nCode,WPARAM wParam,LPARAM lParam)
{
	if(nCode==HC_ACTION)
	{
		KBDLLHOOKSTRUCT *kb=(KBDLLHOOKSTRUCT*) lParam;
		if(wParam==WM_KEYDOWN && GetAsyncKeyState(VK_CONTROL)&0x8000 && GetAsyncKeyState(VK_SHIFT)&0x8000)//切换桌面
			for(auto x:name)
				if(kb->vkCode==x.second && desktops!=x.first)
					turn_desktop(desktops,x.first);
//		if(wParam==WM_KEYDOWN && GetAsyncKeyState(VK_CONTROL)&0x8000 && GetAsyncKeyState(VK_MENU)&0x8000)//移动窗口
//			for(auto x:name)
//				if(kb->vkCode==x.second && desktops!=x.first)
//					turn_desktop(desktops,x.first);
	}
	return CallNextHookEx(hook,nCode,wParam,lParam);
}
LRESULT CALLBACK WndProc(HWND hwnd,UINT Message,WPARAM wParam,LPARAM lParam)
{
	if(Message==WM_PAINT)
	{
		PAINTSTRUCT ps;
		HDC hdc=BeginPaint(hwnd,&ps);
		HBRUSH hBrush=CreateSolidBrush(RGB(0,0,0));
		FillRect(hdc,&ps.rcPaint,hBrush);
		DeleteObject(hBrush);
		SetBkMode(hdc,TRANSPARENT);
		SetTextColor(hdc,RGB(255,255,255));
		SelectObject(hdc,hFont);
		RECT rect;
		GetClientRect(hwnd,&rect);
		string outputs="Desktop: "+string(1,name[desktops]);
		DrawText(hdc,outputs.c_str(),-1,&rect,DT_CENTER|DT_VCENTER|DT_SINGLELINE);
		EndPaint(hwnd,&ps);
	}
	else if(Message==WM_DESTROY)PostQuitMessage(0);
	else return DefWindowProc(hwnd,Message,wParam,lParam);
	return 0;
}
int WINAPI WinMain(HINSTANCE hInstance,HINSTANCE,LPSTR,int)
{
	hFont=CreateFont(30,0,0,0,FW_BOLD,FALSE,FALSE,FALSE,ANSI_CHARSET,OUT_TT_PRECIS,CLIP_DEFAULT_PRECIS,DEFAULT_QUALITY,DEFAULT_PITCH|FF_SWISS,"Arial");
	for(int i=0;i<10;i++)name[i]='0'+i;
	for(char i='A';i<='Z';i++)name[i-'A'+10]=i;
	WNDCLASSEX wc={sizeof(WNDCLASSEX),0,WndProc,0,0,hInstance,NULL,LoadCursor(NULL, IDC_ARROW),(HBRUSH) GetStockObject(NULL_BRUSH),NULL,"MDesktop_Class",LoadIcon(NULL,IDI_APPLICATION)};
	RegisterClassEx(&wc);
	hwndMain=CreateWindowEx(WS_EX_LAYERED|WS_EX_TOPMOST|WS_EX_TOOLWINDOW,"MDesktop_Class","",WS_POPUP,0,0,200,100,NULL,NULL,hInstance,NULL);
	SetLayeredWindowAttributes(hwndMain,RGB(0,0,0),0,LWA_COLORKEY);
	RECT desktopRect;
	GetClientRect(GetDesktopWindow(),&desktopRect);
	SetWindowPos(hwndMain,HWND_TOPMOST,desktopRect.right-200,0,200,100,SWP_SHOWWINDOW);
	hook=SetWindowsHookEx(WH_KEYBOARD_LL,LowLevelKeyboardProc,NULL,0);
	MSG msg;
	while(GetMessage(&msg,NULL,0,0)){TranslateMessage(&msg);DispatchMessage(&msg);}
	UnhookWindowsHookEx(hook);
	DeleteObject(hFont);
	return msg.wParam;
}
